﻿namespace NogorApp.Utilities.ViewModels
{
    public class ResponseRetriveViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string ResponsedOn { get; set; }
        public string ProfilePicture { get; set; }
        public string Body { get; set; }
    }
}
