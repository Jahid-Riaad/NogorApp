﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NogorApp.Utilities
{
    public class Response
    {
        public string message { get; set; }

        public string status { get; set; }

        public int flag { get; set; }
    }
}
